# Projet de Révision Scolaire (Next.js)

## Structure du projet pour Vercel :
1. Déposez le fichier `package.json` directement à la racine de votre GitHub.
2. Créez un dossier nommé `app` sur votre GitHub.
3. Placez vos fichiers (`page.tsx`, `layout.tsx`, `globals.css`, `App.tsx`, `route.ts`) à l'intérieur de ce dossier `app`.

## Configuration Vercel :
- Framework Preset : **Next.js**
- Root Directory : Entièrement vide (racine)
