# révise. — Guide d'installation Cursor

## 1. Crée le projet Next.js

```bash
npx create-next-app@latest revise-app --typescript --tailwind --eslint --app --src-dir --import-alias "@/*"
cd revise-app
```

## 2. Installe les dépendances

```bash
npm install
```

## 3. Configure ta clé API

Crée un fichier `.env.local` à la racine :

```
ANTHROPIC_API_KEY=sk-ant-TA_CLE_ICI
```

Obtiens ta clé sur : https://console.anthropic.com

## 4. Colle les fichiers (voir ci-dessous)

## 5. Lance l'app

```bash
npm run dev
```

→ http://localhost:3000
