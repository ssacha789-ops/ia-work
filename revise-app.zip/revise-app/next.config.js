/** @type {import('next').NextConfig} */
const nextConfig = {
  // Allows the Anthropic API key to be set via env variable
};

module.exports = nextConfig;
